package vjezbeII;
import java.util.Scanner;
public class Dron {

	public static void main(String[] args) {
		
		
		 Scanner sc = new Scanner(System.in);
		 
		 System.out.print("Unesi pocetnu x drona");
		 double dronX = sc.nextDouble();
		 
		 System.out.print("Unesi pocetnu y drona");
		 double dronY = sc.nextDouble();
		 
		 System.out.print("Unesi broj paketa");
		 double N = sc.nextDouble();
		 
		 double xP, yP, UD, zUD = 0 ;
		 
		 for (int i = 0; i < N; i++);
		 
		 
		 
		 

	}

}
