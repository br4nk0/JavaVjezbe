package vjezbeVIII;

public class ObracunPlate {
    private int mesec;
    private int godina;
    private Zaposleni zaposleni;
    private double iznos;
    private String napomena;

    public ObracunPlate(int mesec, int godina, Zaposleni zaposleni, double iznos, String napomena) {
        this.mesec = mesec;
        this.godina = godina;
        this.zaposleni = zaposleni;
        this.iznos = iznos;
        this.napomena = napomena;
    }

    public int getMesec() {
        return mesec;
    }

    public int getGodina() {
        return godina;
    }

    public Zaposleni getZaposleni() {
        return zaposleni;
    }

    public double getIznos() {
        return iznos;
    }

    public String getNapomena() {
        return napomena;
    }

    @Override
    public String toString() {
        return String.format("%02d/%d - %s %s (%s): %.2f EUR %s",
                mesec, godina, zaposleni.getIme(), zaposleni.getPrezime(), zaposleni.getTip(), iznos,
                (napomena == null || napomena.isEmpty()) ? "" : "- " + napomena);
    }
}
