package com.klasa;

public class Prvaklasa {

	public static void main(String[] args) {
		System.out.println("Hello world");

	}

}
