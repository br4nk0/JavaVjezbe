package vjezbeIV;

public class EvidencijaTemperatura {

}
