package vjezbeIV;

public class unosNiza {

	public static void main(String[] args) {

	}

}
