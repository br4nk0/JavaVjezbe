package vjezbeIX;

public interface Attacker {
    int getEffectiveDamage();
}