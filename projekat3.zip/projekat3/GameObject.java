package projekat3;
//Branko Pejanovic 24/028
//Matija Vukovic 24/063

public class GameObject {
    // private attributes
    private int x;
    private int y;
    private int width;
    private int height;

    // konstruktor sa atributima
    public GameObject(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        setWidth(width);
        setHeight(height);
    }

    // getteri i setteri
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        if (width <= 0) {
            throw new IllegalArgumentException("Sirina mora biti veca od nule");
        }
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        if (height <= 0) {
            throw new IllegalArgumentException("Visina mora biti veca od nule");
        }
        this.height = height;
    }

    // provjera da li se dva objekta preklapaju
    public boolean intersects(GameObject other) {
        if (other == null) return false;
        return this.x < other.x + other.width &&
               other.x < this.x + this.width &&
               this.y < other.y + other.height &&
               other.y < this.y + this.height;
    }

    @Override
    public String toString() {
        return String.format("GameObject @ (%d,%d) %dx%d.", x, y, width, height);
    }
}