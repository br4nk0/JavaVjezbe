package projekat3;

import java.util.ArrayList;
import java.util.List;

public class Game {
    private Player player;
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<String> eventLog = new ArrayList<>();

    public Game() {
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public List<Enemy> getEnemies() {
        return enemies;
    }

    public List<String> getEventLog() {
        return eventLog;
    }

    // provjerava da li se igrac i enemy preklapaju
    public boolean checkCollision(Player p, Enemy e) {
        if (p == null || e == null) return false;
        return p.intersects(e);
    }

    // smanjuje health igraca za damage neprijatelja; boss daje duplo
    public void decreaseHealth(Player p, Enemy e) {
        if (p == null || e == null) return;
        int before = p.getHealth();
        int dmg = e.getDamage();
        if (e instanceof BossEnemy) dmg = dmg * 2;
        int after = Math.max(0, before - dmg);
        p.setHealth(after);
        String msg = String.format("HIT: Player by %s for %d -> HP %d -> %d", e.getType(), dmg, before, after);
        eventLog.add(msg);
    }

    // dodaje neprijatelja u listu i upisuje u log
    public void addEnemy(Enemy e) {
        if (e == null) return;
        enemies.add(e);
        eventLog.add("ADD: " + e.toString());
    }

    // vraca sve neprijatelje ciji tip sadrzi query
    public List<Enemy> findByType(String query) {
        List<Enemy> res = new ArrayList<>();
        if (query == null) return res;
        for (Enemy e : enemies) {
            if (e.matchesType(query)) res.add(e);
        }
        return res;
    }

    // vraca listu neprijatelja koji se sudaraju sa igracem
    public List<Enemy> collidingWithPlayer() {
        List<Enemy> res = new ArrayList<>();
        if (player == null) return res;
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) res.add(e);
        }
        return res;
    }

    // prolazi kroz sve neprijatelje i rjesava sudare
    public void resolveCollisions() {
        if (player == null) return;
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                decreaseHealth(player, e);
            }
        }
    }

    // pomocna funkcija za parsiranje stringa u neprijatelja
    private Enemy parseEnemyString(String s) {
        if (s == null) return null;
        String[] parts = s.split(";");
        if (parts.length < 4) return null;
        try {
            String type = parts[0].trim();
            String[] xy = parts[1].split(",");
            int x = Integer.parseInt(xy[0].trim());
            int y = Integer.parseInt(xy[1].trim());
            String[] wh = parts[2].toLowerCase().split("x");
            int w = Integer.parseInt(wh[0].trim());
            int h = Integer.parseInt(wh[1].trim());
            int dmg = Integer.parseInt(parts[3].trim());
            boolean isBoss = parts.length >= 5 && "boss".equalsIgnoreCase(parts[4].trim());
            int health = 100; 
            if (isBoss) {
                return new BossEnemy(x, y, w, h, type, dmg, health);
            } else {
                return new MeleeEnemy(x, y, w, h, type, dmg, health);
            }
        } catch (Exception ex) {
            return null;
        }
    }

    public static void main(String[] args) {
        Game game = new Game();

        Player p = new Player(10, 5, 32, 32, "Igrac", 100);
        game.setPlayer(p);

        
        MeleeEnemy m = new MeleeEnemy(12, 5, 32, 32, "Mel", 10, 50);
        game.addEnemy(m);

        /
        String enemyStr = "Goblin;12,5;16x16;20;boss";
        Enemy parsed = game.parseEnemyString(enemyStr);
        if (parsed != null) game.addEnemy(parsed);

        
        System.out.println("Svi neprijatelji:");
        for (Enemy e : game.getEnemies()) {
            System.out.println(e.toString());
        }

        // pronadji oni koji sadrze "gob"
        System.out.println("\nPronadji goblina 'gob'");
        for (Enemy e : game.findByType("gob")) System.out.println(e.toString());

        // prikazi stanje igraca prije
        System.out.println("\n Igrac prije kolizije:  " + game.getPlayer().toString());

        // provjeri kolizije
        System.out.println("\n Kolizije sa igracem:");
        for (Enemy e : game.collidingWithPlayer()) System.out.println(e.toString());

        // rijesi kolizije
        game.resolveCollisions();

        // prikazi stanje igraca poslije
        System.out.println("\nIgrac posle: " + game.getPlayer().toString());

        // ispisi event log
        System.out.println("\nEvent Log:");
        for (String log : game.getEventLog()) System.out.println(log);
    }
}
