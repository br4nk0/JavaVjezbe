package projekat3;

public class Player extends GameObject {
    private String name;
    private int health; 

    public Player(int x, int y, int width, int height, String name, int health) {
        super(x, y, width, height);
        setName(name);
        setHealth(health);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null) throw new IllegalArgumentException("Ime ne moze da bude null");
        String normalized = normalizeName(name);
        this.name = normalized;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health < 0 || health > 100) {
            throw new IllegalArgumentException("Health mora da bude izmedju 0 and 100");
        }
        this.health = health;
    }

    private String normalizeName(String raw) {
    	
        // trimuje razmake i svaku rijec pocinje velikim slovom
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) return "";
        String[] parts = trimmed.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i].toLowerCase();
            if (p.length() > 0) {
                sb.append(Character.toUpperCase(p.charAt(0)));
                if (p.length() > 1) sb.append(p.substring(1));
            }
            if (i < parts.length - 1) sb.append(' ');
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return String.format("Player[%s] @ (%d,%d) %dx%d HP=%d", name, getX(), getY(), getWidth(), getHeight(), health);
    }
}
