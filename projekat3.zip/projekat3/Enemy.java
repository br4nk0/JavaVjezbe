package projekat3;

public class Enemy extends GameObject {
    private String type;
    private int damage; 
    private int health; 

    public Enemy(int x, int y, int width, int height, String type, int damage, int health) {
        super(x, y, width, height);
        setType(type);
        setDamage(damage);
        setHealth(health);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        if (type == null) throw new IllegalArgumentException("Tip ne moze da bude null");
        String t = type.trim();
        
        // Prvo slovo treba da bude veliko
        String[] parts = t.toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i];
            if (p.length() > 0) {
                sb.append(Character.toUpperCase(p.charAt(0)));
                if (p.length() > 1) sb.append(p.substring(1));
            }
            if (i < parts.length - 1) sb.append(' ');
        }
        this.type = sb.toString();
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        if (damage < 0 || damage > 100) {
            throw new IllegalArgumentException("Damage mora bit izmedju 0 i 100");
        }
        this.damage = damage;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health < 0 || health > 100) {
            throw new IllegalArgumentException("Health mora bit izmedju 0 i 100");
        }
        this.health = health;
    }

    //Provjera da li tip sadrzi dati upit npr. case insensitive ili trimovan
    
    public boolean matchesType(String query) {
        if (query == null) return false;
        return type.toLowerCase().contains(query.trim().toLowerCase());
    }

    @Override
    public String toString() {
        return String.format("Enemy[%s] @ (%d,%d) %dx%d DMG=%d HP=%d.", type, getX(), getY(), getWidth(), getHeight(), damage, health);
    }
}
