package projekat3;

public class MeleeEnemy extends Enemy {

    public MeleeEnemy(int x, int y, int width, int height, String type, int damage, int health) {
        super(x, y, width, height, type, damage, health);
    }

   // MeleeEnemy daje normalan damage
    
    
    public int getAttackDamage() {
        return getDamage();
    }

    @Override
    public String toString() {
        return String.format("MeleeEnemy[%s] @ (%d,%d) %dx%d DMG=%d HP=%d.",
                getType(), getX(), getY(), getWidth(), getHeight(), getDamage(), getHealth());
    }
}