package projekat;

public class TestVozila {
    public static void main(String[] args) {
    	
        Automobil a = new Automobil("Toyota", 2008, 2200, "crvena", 4, "dizel");
        Kamion k = new Kamion("MAN", 2015, 5000, "bijela", 5000, true);
        Kombi kb = new Kombi("Ford", 2012, 2000, "plava", 9);

        ispisiAutomobil (a);
        ispisiKamion(k);
        ispisiKombi(kb);
    }

    public static void ispisiAutomobil(Automobil a) {
        System.out.println("Automobil");
        System.out.println("Proizvodjac: " + a.getProizvodjac());
        System.out.println("Godina proizvodnje: " + a.getGodinaProizvodnje());
        System.out.println("Kubikaza: " + a.getKubikaza());
        System.out.println("Boja: " + a.getBoja());
        System.out.println("Broj vrata: " + a.getBrojVrata());
        System.out.println("Tip motora: " + a.getTipMotora());
        System.out.println("Ukupna cijena registracije: " + a.cijenaRegistracije());
    }

    public static void ispisiKamion(Kamion k) {
        System.out.println("Kamion");
        System.out.println("Proizvodjac: " + k.getProizvodjac());
        System.out.println("Godina proizvodnje: " + k.getGodinaProizvodnje());
        System.out.println("Kubikaza: " + k.getKubikaza());
        System.out.println("Boja: " + k.getBoja());
        System.out.println("Kapacitet tereta: " + k.getKapacitetTereta());
        System.out.println("Ima prikolicu: " + (k.isPrikolica() ? "da" : "ne"));
        System.out.println("Ukupna cijena registracije: " + k.cijenaRegistracije());
    }

    public static void ispisiKombi(Kombi kb) {
        System.out.println("Kombi");
        System.out.println("Proizvodjac: " + kb.getProizvodjac());
        System.out.println("Godina proizvodnje: " + kb.getGodinaProizvodnje());
        System.out.println("Kubikaza: " + kb.getKubikaza());
        System.out.println("Boja: " + kb.getBoja());
        System.out.println("Kapacitet putnika: " + kb.getKapacitetPutnika());
        System.out.println("Ukupna cijena registracije: " + kb.cijenaRegistracije());
    }
}