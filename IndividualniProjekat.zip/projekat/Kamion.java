package projekat;

public class Kamion extends Vozilo {
    private int kapacitetTereta; // u kilogramima
    private boolean prikolica; // true = ima prikolicu

    public Kamion(String proizvodjac, int godinaProizvodnje, int kubikaza, String boja, int kapacitetTereta, boolean prikolica) {
        super(proizvodjac, godinaProizvodnje, kubikaza, boja);
        this.kapacitetTereta = kapacitetTereta;
        this.prikolica = prikolica;
    }

    public int getKapacitetTereta() {
        return kapacitetTereta;
    }

    public void setKapacitetTereta(int kapacitetTereta) {
        this.kapacitetTereta = kapacitetTereta;
    }

    public boolean isPrikolica() {
        return prikolica;
    }

    public void setPrikolica(boolean prikolica) {
        this.prikolica = prikolica;
    }

    public int cijenaRegistracije() {
        int cijena = super.cijenaRegistracije();
        if (this.prikolica) {
            cijena += 50;
        }
        return cijena;
    }

}